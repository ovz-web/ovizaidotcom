-- =====================================================================
-- OVIZai — Migration table `leads`
-- À exécuter dans Supabase Dashboard > SQL Editor
--
-- Contexte : /api/leads n'écrivait historiquement que la colonne `email`.
-- Le nom, le type de projet, le budget, la devise et le message du brief
-- qualifié (formulaire /contact) étaient silencieusement perdus. Cette
-- migration ajoute les colonnes manquantes de façon idempotente
-- (IF NOT EXISTS), donc sûre à rejouer plusieurs fois.
-- =====================================================================

-- 1. Ajout des colonnes manquantes sur la table existante `leads`
ALTER TABLE public.leads
  ADD COLUMN IF NOT EXISTS name text,
  ADD COLUMN IF NOT EXISTS project_type text,
  ADD COLUMN IF NOT EXISTS budget_range text,
  ADD COLUMN IF NOT EXISTS currency text,
  ADD COLUMN IF NOT EXISTS message text,
  ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();

-- 2. S'assurer que l'email reste unique (nécessaire pour la gestion du
--    doublon 23505 déjà gérée dans /api/leads/route.ts)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'leads_email_key'
  ) THEN
    ALTER TABLE public.leads ADD CONSTRAINT leads_email_key UNIQUE (email);
  END IF;
END $$;

-- 3. Row Level Security : la table doit rester fermée en lecture/écriture
--    publique. Seule la clé service_role (utilisée exclusivement côté
--    serveur dans /api/leads) doit pouvoir écrire.
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;

-- Supprime d'éventuelles anciennes policies permissives avant recréation
DROP POLICY IF EXISTS "Allow service_role full access" ON public.leads;

CREATE POLICY "Allow service_role full access"
  ON public.leads
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Aucune policy pour `anon` / `authenticated` : les visiteurs ne peuvent
-- pas lire ou écrire directement dans `leads` depuis le navigateur, tout
-- passe obligatoirement par la route serveur /api/leads.

-- 4. Vérification rapide de la structure finale
-- SELECT column_name, data_type, is_nullable
-- FROM information_schema.columns
-- WHERE table_schema = 'public' AND table_name = 'leads'
-- ORDER BY ordinal_position;
