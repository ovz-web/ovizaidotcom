import { createClient } from '@supabase/supabase-js';

// SECURITY: no hardcoded fallback. The service_role key bypasses Row Level
// Security entirely — it must live ONLY in Vercel/host environment variables,
// never in source code. Fail fast and loud if it's missing instead of
// silently falling back to a value that could leak into git history.
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  throw new Error(
    '[supabaseServer] Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY environment variables. ' +
    'Set them in your Vercel project settings (or .env.local for local dev) — never hardcode them in source.'
  );
}

export const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);
